import os

import torch
from torch.utils.data import Dataset
from torchvision import transforms

import image
from torch.utils.data import DataLoader
from segmentation_helper import show_rgb, show_mask, check_dataset, check_dataloader


class RGBDataset(Dataset):
    # TODO
    def __init__(self, dataset_dir, has_gt):
        """
        In:
            img_dir: string, path of train, val or test folder.
            has_gt: bool, indicating if the dataset has ground truth masks.
        Out:
            None.
        Purpose:
            Initialize instance variables.
        Hint:
            Check __getitem__() and add more instance variables to initialize what you need in this method.
        """
        # Input normalization info
        mean_rgb = [0.722, 0.751, 0.807]
        std_rgb = [0.171, 0.179, 0.197]

        self.dataset_dir = dataset_dir
        self.has_gt = has_gt
        # transform to be applied on a sample.
        # For this homework, compose ToTensor() and normalization for RGB image should be enough.
        self.transform = transforms.Compose(
            [transforms.ToTensor(),
             transforms.Normalize(mean=mean_rgb, std=std_rgb),
             ])
        self.mask_transform = transforms.ToTensor()
        # number of samples in the dataset.
        # You'd better not hard code the number, because this class is used to create train, validation and test dataset.
        filenames = os.listdir(os.path.join(self.dataset_dir, 'rgb'))
        self.dataset_length = len(filenames)
        if '.DS_Store' in filenames:
            self.dataset_length -= 1

    def __len__(self):
        return self.dataset_length

    def __getitem__(self, idx):
        """
        In:
            idx: int, index of each sample, in range(0, dataset_length).
        Out:
            sample: a dictionary that stores paired rgb image and corresponding ground truth mask (if available).
                    rgb_img: Tensor [3, height, width]
                    target: Tensor [height, width], use torch.LongTensor() to convert.
        Purpose:
            Given an index, return paired rgb image and ground truth mask as a sample.
        Hint:
            Use image.read_rgb() and image.read_mask() to read the images.
            Look at the filenames and think about how to associate idx with the file name of images.
            Remember to apply transform on the sample.
        """
        rgb_path = os.path.join(self.dataset_dir, f'rgb/{idx}_rgb.png') 
        gt_path = os.path.join(self.dataset_dir, f'gt/{idx}_gt.png')
        rgb_img = image.read_rgb(rgb_path)
        rgb_img = self.transform(rgb_img)

        if self.has_gt is False:
            sample = {'input': rgb_img}
        else:
            
            gt_mask = image.read_mask(gt_path)
            gt_mask = self.mask_transform(gt_mask).squeeze().long()
            sample = {'input': rgb_img, 'target': gt_mask}
        return sample


if __name__ == "__main__":
    ds = RGBDataset('dataset/train', True)
    # sample = ds[2]
    check_dataset(ds)
    dl = DataLoader(ds, batch_size=8, shuffle=True, num_workers=1)
    check_dataloader(dl)
    # show_rgb(sample['input'])
    # show_mask(sample['target']) 

