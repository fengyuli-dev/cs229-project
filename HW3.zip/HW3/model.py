import torch
import torch.nn as nn
import torch.nn.functional as F


class MiniUNet(nn.Module):
    # TODO: implement a neural network as described in the handout
    def __init__(self):
        """Initialize the layers of the network as instance variables."""
        super(MiniUNet, self).__init__()
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.conv4 = nn.Conv2d(64, 128, kernel_size=3, padding=1)
        self.conv_bottom = nn.Conv2d(128, 256, kernel_size=3, padding=1)

        self.upsample = F.interpolate(scale_factor=2.0)
        self.conv4_up = nn.Conv2d(384, 128, kernel_size=3, padding=1)
        self.conv3_up = nn.Conv2d(192, 64, kernel_size=3, padding=1)
        self.conv2_up = nn.Conv2d(96, 32, kernel_size=3, padding=1)
        self.conv1_up = nn.Conv2d(48, 16, kernel_size=3, padding=1)
        self.conv1x1 = nn.Conv2d(16, 6, kernel_size=1, padding=0)

    def forward(self, x):
        """
        In:
            x: Tensor [batchsize, channel, height, width], channel=3 for rgb input
        Out:
            output: Tensor [batchsize, class, height, width], class=number of objects + 1 for background
        Purpose:
            Forward process. Pass the input x through the layers defined in __init__() to get the output.
        """
        x1 = F.relu(self.conv1(x))  
        x2 = self.pool1(x1)
        x2 = F.relu(self.conv2(x2))  
        x3 = self.pool2(x2)
        x3 = F.relu(self.conv3(x3))  
        x4 = self.pool3(x3)
        x4 = F.relu(self.conv4(x4))  
        x_bottom = self.pool4(x4)
        x_bottom = self.conv_bottom(x_bottom)
        x_up = F.interpolate(x_bottom, scale_factor=2)
        x_up = F.relu(self.conv4_up(torch.cat([x4, x_up], dim=1)))
        x_up = F.interpolate(x_up, scale_factor=2)
        x_up = F.relu(self.conv3_up(torch.cat([x3, x_up], dim=1)))
        x_up = F.interpolate(x_up, scale_factor=2)
        x_up = F.relu(self.conv2_up(torch.cat([x2, x_up], dim=1)))
        x_up = F.interpolate(x_up, scale_factor=2)
        x_up = F.relu(self.conv1_up(torch.cat([x1, x_up], dim=1)))
        output = self.conv1x1(x_up)
        return output


if __name__ == '__main__':
    model = MiniUNet()
    input_tensor = torch.zeros([1, 3, 240, 320])
    output = model(input_tensor)
    print("output size:", output.size())
    print(model)
