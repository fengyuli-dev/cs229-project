from image import read_mask, write_mask
from segmentation_helper import show_mask, show_rgb

if __name__ == "__main__":
    print("Process starting") 
    file = 'dataset/train/gt/13_gt.png'
    mask = read_mask(file)
    show_mask(mask)



# Problem 2.1.3
# There is one channel for each label, there are in total 6 labels including the background. Each channel stands for the probability a pixel is from the class corresponding to this channel. For example, if we predict that a pixel belongs to a bowl, the value for the bowl channel should be higher than all other channels. We need to change 1) the labels of the dataset 2) the output size 3) the loss function to regression.